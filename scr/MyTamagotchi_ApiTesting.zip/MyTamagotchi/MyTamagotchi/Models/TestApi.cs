﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyTamagotchi.Models
{
    public class TestApi
    {
        public async Task DisplayPets()
        {
            PetApiService api = new PetApiService();
            List<Pet> pets = await api.GetTestPets();
            foreach (Pet pet in pets) 
            {
                Debug.WriteLine(pet.ToString());
            }

        }
        public static async Task Main(string[] args)
        {
            Debug.WriteLine("+++ MY INFO: Starte TestMain...");
            TestApi testMain = new TestApi();
            await testMain.DisplayPets();
        }
    }
}
