﻿using System.Windows;

namespace MyTamagotchi
{
    public partial class App : Application
    {
        
    }
}
